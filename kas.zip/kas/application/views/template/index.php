<?php
$this->template->cek_login();
?>
		<?= $header ;?>
		<div class="main-panel">
			<div class="content">
			<div class="page-inner">
				<?= $content ;?>
			</div>
			</div>
			
		<?= $footer ;?>
			